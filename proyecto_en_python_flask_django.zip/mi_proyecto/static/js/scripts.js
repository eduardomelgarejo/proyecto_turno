// Aquí puedes añadir interacciones JavaScript
document.addEventListener('DOMContentLoaded', function() {
    console.log("Página cargada");
});
